const mysql = require("mysql2")
const sha256 = require('sha256')

const dbconf = {
  localhost: 'localhost',
  user: 'root',
  password: '',
  database: 'uchettmc'
}

const con = mysql.createConnection(dbconf)

setInterval(() => {
  con.query('SELECT 1')
}, 5000)

module.exports = {
  getDB() {
    class Database {
      constructor(config) {
        this.connection = mysql.createConnection(config)
      }
      query(sql, args) {
        return new Promise((resolve , reject) => {
          this.connection.query(sql, args, (err, rows) => {
            if (err)
              return reject(err)
            resolve(rows)
          })
        })
      }
      close() {
        return new Promise( (resolve, reject) => {
          this.connection.end(err => {
            if (err)
              reject(err)
            resolve()
          })
        })
      }
    }

    return new Database(dbconf)

  },
}