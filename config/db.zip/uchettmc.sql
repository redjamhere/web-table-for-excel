-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Дек 20 2019 г., 18:45
-- Версия сервера: 10.3.13-MariaDB-log
-- Версия PHP: 7.1.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `uchettmc`
--

-- --------------------------------------------------------

--
-- Структура таблицы `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `ShortName` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `FullName` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Level` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `services`
--

INSERT INTO `services` (`id`, `ShortName`, `FullName`, `Level`) VALUES
(1, 'service_211', 'СЗЦ-211', 1),
(3, 'service_220', 'СЗЦ-220', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `service_211_depadmin`
--

CREATE TABLE `service_211_depadmin` (
  `id` int(11) NOT NULL,
  `ПоззаявкиСП` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `НомерзаявкиСП` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Материал` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `КрТекстМатериала` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Единицаизмерения` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `КолвозаявкаСП` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ЦенабезНДС` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `СтоимбезНДС` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Годзаявкампании` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Статус` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Датапоставки` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Срокдоставкидн` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ДатасогласованиязаявкаСП` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ЗаявкаСПОписание` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Taбномер` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Прайспоставщикнаим` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Номердоговора` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Заказчик` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ГруппаСостояние` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Адресразмещения` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ФИОпользователяподразделение` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Техническиеатребуты` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ПоззаявкиСП, НомерзаявкиСП, Материал, КрТекстМатериала, Единицаизмерения, КолвозаявкаСП, ЦенабезНДС, СтоимбезНДС, Годзаявкампании, Статус, Датапоставки, Срокдоставкидн, ДатасогласованиязаявкаСП, ЗаявкаСПОписание, Taбномер, Прайспоставщикнаим, Номердоговора, Заказчик, ГруппаСостояние, Адресразмещения, ФИОпользователяподразделение, Техническиеатребуты';

--
-- Дамп данных таблицы `service_211_depadmin`
--

INSERT INTO `service_211_depadmin` (`id`, `ПоззаявкиСП`, `НомерзаявкиСП`, `Материал`, `КрТекстМатериала`, `Единицаизмерения`, `КолвозаявкаСП`, `ЦенабезНДС`, `СтоимбезНДС`, `Годзаявкампании`, `Статус`, `Датапоставки`, `Срокдоставкидн`, `ДатасогласованиязаявкаСП`, `ЗаявкаСПОписание`, `Taбномер`, `Прайспоставщикнаим`, `Номердоговора`, `Заказчик`, `ГруппаСостояние`, `Адресразмещения`, `ФИОпользователяподразделение`, `Техническиеатребуты`) VALUES
(1, 'ewqewq', '0ewqeqw', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'),
(2, '0000000001dqwdqdqw', '0000010682', '411000000000920250', 'Метран-55-Вн-ДА-505-МП-t1-050-0.6МПа-42С', 'ШТ', '3,000', '10713,00', '32139,00', '2019', '60 - Заявка закрыта', 'декабрь 2019', '0', '20.09.2019', '211 ЗИП Азнакаевскнефть', '_', 'АО ПГ \"Метран\"', '333/19/234 СП 771/66', '_', '_', '_', '_', '_'),
(3, '0000000002', '0000010682', '411000000000827755', 'Датчик ДАХ-М-03-HCL30 ИБЯЛ.413412.005-02', 'ШТ', '1,000', '22297,77', '22297,77', '2019', '60 - Заявка закрыта', 'декабрь 2019', '0', '26.09.2019', '211 ЗИП Азнакаевскнефть', '_', 'ФГУП СПО \"Аналитприбор\"', '0350/771/1140/16/33/5/118 СП 7', '_', '_', '_', '_', '_'),
(4, '0000000003', '0000010682', '411000000000950645', 'Уровнемер ДУУ4МА-(ДУУ2М-12-0)-15,0-1', 'ШТ', '1,000', '117646,50', '117646,50', '2019', '40/4 - Заключен договор', 'декабрь 2019', '0', '10.10.2019', '211 ЗИП Азнакаевскнефть', '_', 'ЗАО \"Альбатрос\"', '0350/713/3960/16/087/16-П СП 7', '_', '_', '_', '_', '_'),
(5, '0000000004', '0000010682', '411000000001049601', 'Датчик пламени СЛ-90-1/220Е', 'ШТ', '1,000', '11750,00', '11750,00', '2019', '40/4 - Заключен договор', 'декабрь 2019', '0', '18.10.2019', '211 ЗИП Азнакаевскнефть', '_', 'ООО \"Энерго-ТК\"', '0350/771/12/18 СП 771/19', '_', '_', '_', '_', '_'),
(6, '0000000005', '0000010682', '411000000000869966', 'Датчик НОРД-И2ДУ-04', 'ШТ', '1,000', '12000,00', '12000,00', '2019', '60 - Заявка закрыта', 'ноябрь 2019', '0', '04.10.2019', '211 ЗИП Азнакаевскнефть', '_', 'ООО \"НПП \"БЗНГА\"', '0350/713/670/16 СП 771/38', '_', '_', '_', '_', '_'),
(7, '0000000006', '0000010682', '411000000000732771', 'ТСПУ Метран276-08Exd100-0,5-H10(-50+100)', 'ШТ', '1,000', '6415,00', '6415,00', '2019', '40/4 - Заключен договор', 'ноябрь 2019', '0', '04.10.2019', '211 ЗИП Азнакаевскнефть', '_', 'ООО \"Энерго-ТК\"', '0350/771/1150/18', '_', '_', '_', '_', '_'),
(8, '0000000007', '0000010682', '411000000000961222', 'ТСМ-Метран2000(-50+150)50М В-4-1-А02-200', 'ШТ', '10,000', '3137,45', '31374,50', '2019', '40/4 - Заключен договор', 'ноябрь 2019', '0', '18.10.2019', '211 ЗИП Азнакаевскнефть', '_', 'ООО \"Энерго-ТК\"', '0350/771/12/18 СП 771/19', '_', '_', '_', '_', '_'),
(9, '0000000008', '0000010682', '411000000000994856', 'Датчик Метран-150CD2(0...63кПа)2211L3AM5', 'ШТ', '1,000', '48923,93', '48923,93', '2019', '40/4 - Заключен договор', 'ноябрь 2019', '0', '18.10.2019', '211 ЗИП Азнакаевскнефть', '_', 'ООО \"Энерго-ТК\"', '0350/771/12/18 СП 771/19', '_', '_', '_', '_', '_'),
(10, '0000000009', '0000010682', '411000000000167235', 'Комплект дат.к СТМ-10 ИБЯЛ305658001', 'ШТ', '11,000', '702,00', '7722,00', '2019', '60 - Заявка закрыта', 'октябрь 2019', '0', '25.09.2019', '211 ЗИП Азнакаевскнефть', '_', '_', '_', '_', '_', '_', '_', '_'),
(11, '0000000010', '0000010682', '411000000000884594', 'Уровнемер ДУУ4МА-(ДУУ2М-14-0)-12,0', 'ШТ', '1,000', '125618,00', '125618,00', '2019', '40/4 - Заключен договор', 'декабрь 2019', '0', '10.10.2019', '211 ЗИП Азнакаевскнефть', '_', 'ЗАО \"Альбатрос\"', '0350/713/3960/16/087/16-П СП 7', '_', '_', '_', '_', '_'),
(12, '0000000011', '0000010682', '411000000000816848', 'Контроллер СГМ110-А/D/', 'ШТ', '2,000', '20000,00', '40000,00', '2019', '40/4 - Заключен договор', 'декабрь 2019', '0', '15.10.2019', '211 ЗИП Азнакаевскнефть', '_', 'ООО \"Эрис КИП\"', '0350/713/3518/15 СП 102', '_', '_', '_', '_', '_'),
(13, '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_'),
(14, '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_'),
(15, '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_');

-- --------------------------------------------------------

--
-- Структура таблицы `service_211_depeco`
--

CREATE TABLE `service_211_depeco` (
  `id` int(11) NOT NULL,
  `ПоззаявкиСП` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `НомерзаявкиСП` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Материал` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `КрТекстМатериала` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Единицаизмерения` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `КолвозаявкаСП` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ЦенабезНДС` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `СтоимбезНДС` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Годзаявкампании` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Статус` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Датапоставки` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Срокдоставкидн` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ДатасогласованиязаявкаСП` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ЗаявкаСПОписание` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Taбномер` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Прайспоставщикнаим` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Номердоговора` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Заказчик` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ГруппаСостояние` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Адресразмещения` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ФИОпользователяподразделение` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Техническиеатребуты` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ПоззаявкиСП, НомерзаявкиСП, Материал, КрТекстМатериала, Единицаизмерения, КолвозаявкаСП, ЦенабезНДС, СтоимбезНДС, Годзаявкампании, Статус, Датапоставки, Срокдоставкидн, ДатасогласованиязаявкаСП, ЗаявкаСПОписание, Taбномер, Прайспоставщикнаим, Номердоговора, Заказчик, ГруппаСостояние, Адресразмещения, ФИОпользователяподразделение, Техническиеатребуты';

--
-- Дамп данных таблицы `service_211_depeco`
--

INSERT INTO `service_211_depeco` (`id`, `ПоззаявкиСП`, `НомерзаявкиСП`, `Материал`, `КрТекстМатериала`, `Единицаизмерения`, `КолвозаявкаСП`, `ЦенабезНДС`, `СтоимбезНДС`, `Годзаявкампании`, `Статус`, `Датапоставки`, `Срокдоставкидн`, `ДатасогласованиязаявкаСП`, `ЗаявкаСПОписание`, `Taбномер`, `Прайспоставщикнаим`, `Номердоговора`, `Заказчик`, `ГруппаСостояние`, `Адресразмещения`, `ФИОпользователяподразделение`, `Техническиеатребуты`) VALUES
(1, 'За орду', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'),
(2, '_', 'dqwdqwdqw', 'dwqdqwdwq', 'dwqdqdqw', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_'),
(3, '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_'),
(4, 'dwqdqwdwq', 'dwqdqw', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_'),
(5, '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_'),
(6, 'dwqdqwdqw', 'dwqdqwdqw', 'dwqdqwdwq', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_'),
(7, '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_');

-- --------------------------------------------------------

--
-- Структура таблицы `service_211_depproiz`
--

CREATE TABLE `service_211_depproiz` (
  `id` int(11) NOT NULL,
  `ПоззаявкиСП` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `НомерзаявкиСП` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Материал` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `КрТекстМатериала` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Единицаизмерения` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `КолвозаявкаСП` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ЦенабезНДС` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `СтоимбезНДС` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Годзаявкампании` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Статус` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Датапоставки` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Срокдоставкидн` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ДатасогласованиязаявкаСП` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ЗаявкаСПОписание` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Taбномер` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Прайспоставщикнаим` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Номердоговора` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Заказчик` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ГруппаСостояние` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Адресразмещения` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ФИОпользователяподразделение` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Техническиеатребуты` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='ПоззаявкиСП, НомерзаявкиСП, Материал, КрТекстМатериала, Единицаизмерения, КолвозаявкаСП, ЦенабезНДС, СтоимбезНДС, Годзаявкампании, Статус, Датапоставки, Срокдоставкидн, ДатасогласованиязаявкаСП, ЗаявкаСПОписание, Taбномер, Прайспоставщикнаим, Номердоговора, Заказчик, ГруппаСостояние, Адресразмещения, ФИОпользователяподразделение, Техническиеатребуты';

--
-- Дамп данных таблицы `service_211_depproiz`
--

INSERT INTO `service_211_depproiz` (`id`, `ПоззаявкиСП`, `НомерзаявкиСП`, `Материал`, `КрТекстМатериала`, `Единицаизмерения`, `КолвозаявкаСП`, `ЦенабезНДС`, `СтоимбезНДС`, `Годзаявкампании`, `Статус`, `Датапоставки`, `Срокдоставкидн`, `ДатасогласованиязаявкаСП`, `ЗаявкаСПОписание`, `Taбномер`, `Прайспоставщикнаим`, `Номердоговора`, `Заказчик`, `ГруппаСостояние`, `Адресразмещения`, `ФИОпользователяподразделение`, `Техническиеатребуты`) VALUES
(1, 'За альянс', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0'),
(2, '_', 'dqwdqw', 'dwqdqwdwq', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_'),
(3, '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_'),
(4, '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_'),
(5, '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_'),
(6, '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_', '_');

-- --------------------------------------------------------

--
-- Структура таблицы `service_departs`
--

CREATE TABLE `service_departs` (
  `id` int(11) NOT NULL,
  `Shortname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Fullname` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `Level` int(11) NOT NULL DEFAULT 0,
  `Parent` int(11) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `service_departs`
--

INSERT INTO `service_departs` (`id`, `Shortname`, `Fullname`, `Level`, `Parent`) VALUES
(1, 'service_211_depadmin', 'Отдел администрирования и развития АСУТП', 1, 1),
(2, 'service_211_depproiz', 'Производственная служба', 2, 1),
(3, 'service_211_depeco', 'Экономическая служба', 2, 1),
(4, 'service_220_depadmin', 'Отдел админ где сидят люди', 2, 3),
(5, 'service_220_depproiz', 'Тут произвоидство соре', 3, 3),
(6, 'service_220_depeco', 'Экономический гуру', 2, 3);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `Firstname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Lastname` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Middlename` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Readwrite` int(1) DEFAULT NULL,
  `DepartViewPermission` int(11) DEFAULT NULL,
  `ServiceViewPermission` int(11) DEFAULT NULL,
  `DepartName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ServiceName` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `Firstname`, `Lastname`, `Middlename`, `username`, `password`, `Readwrite`, `DepartViewPermission`, `ServiceViewPermission`, `DepartName`, `ServiceName`) VALUES
(1, 'Займанов', 'Айнур', 'Альбертович', 'user', 'user', 1, 1, 1, 'service_211_depadmin', 'service_211'),
(2, 'Иванов', 'Иван', 'Иванович', 'user1', 'user1', 1, 2, 1, 'service_211_depeco', 'service_211'),
(3, 'Петров', 'Петр', 'Петрович', 'user2', 'user2', 0, 2, 1, 'service_211_depproiz', 'service_211');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `service_211_depadmin`
--
ALTER TABLE `service_211_depadmin`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `service_211_depeco`
--
ALTER TABLE `service_211_depeco`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `service_211_depproiz`
--
ALTER TABLE `service_211_depproiz`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `service_departs`
--
ALTER TABLE `service_departs`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `service_211_depadmin`
--
ALTER TABLE `service_211_depadmin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `service_211_depeco`
--
ALTER TABLE `service_211_depeco`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT для таблицы `service_211_depproiz`
--
ALTER TABLE `service_211_depproiz`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `service_departs`
--
ALTER TABLE `service_departs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
